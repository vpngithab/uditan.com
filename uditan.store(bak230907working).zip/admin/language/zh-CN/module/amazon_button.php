<?php
// Heading
$_['heading_title']    = '亚马逊支付按钮';

$_['text_module']      = '模块管理';
$_['text_success']     = '已成功修改亚马逊支付按钮(亚马逊支付)模组设置';
$_['text_edit']        = '编辑亚马逊支付模块';
$_['text_left']        = '左列';
$_['text_right']       = '右列';
$_['text_center']      = '中部';

// Entry
$_['entry_name']       = '模块名称';
$_['entry_align']      = '对齐';
$_['entry_status']     = '状态';

// Error
$_['error_permission']     = '警告：您没有权限修亚马逊支付模块！';
$_['error_name']       = '模块名称必须是 3 至 64 个字符之间！';