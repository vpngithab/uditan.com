<?php
// Heading
$_['heading_title']     = '订单配置';

// Text
$_['text_success']      = '成功: 您已经修改了配置！';
$_['text_list']         = '订单配置列表';

// Column
$_['column_name']       = '订单配置';
$_['column_status']     = '状态';
$_['column_sort_order'] = '排序';
$_['column_action']     = '管理';

// Error
$_['error_permission']  = '警告： 您没有权限修改订单配置！';