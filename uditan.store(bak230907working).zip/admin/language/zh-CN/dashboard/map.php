<?php
// Heading
$_['heading_title'] = '整体概要';

$_['text_order']    = '订单';
$_['text_sale']     = '销售';