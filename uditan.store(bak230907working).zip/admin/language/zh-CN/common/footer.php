<?php
// Text
$_['text_footer'] 	= '<a href="http://ditan.store">又来®地摊连锁</a> &copy; 2020-' . date('Y');
// $_['text_version'] 	= 'Version %s';