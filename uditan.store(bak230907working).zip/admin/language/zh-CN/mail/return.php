<?php
// Text
$_['text_subject']       = '%s - 退货  %s 更新';
$_['text_return_id']     = '退货 ID：';
$_['text_date_added']    = '退货的日期：';
$_['text_return_status'] = '您的退货已更新到以下状态：';
$_['text_comment']       = '您退货的意见：';
$_['text_footer']        = '如果您有任何问题请回复这个电子邮件。';