<?php
// Heading
$_['heading_title']    = '谷歌扩展';

// Text
$_['text_feed']        = '插件扩展';
$_['text_success']     = '成功： 您已变更谷歌扩展！';
$_['text_list']        = '布局列表';
$_['text_edit']        = '编辑谷歌扩展';

// Entry
$_['entry_status']     = '状态：';
$_['entry_data_feed']  = '资料数据网址：';

// Error
$_['error_permission'] = '警告： 您没有权限修改谷歌扩展！';