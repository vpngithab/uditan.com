<?php
// Heading
$_['heading_title']    = '商店信用';

// Text
$_['text_total']       = '订单总计';
$_['text_success']     = '成功商店信用更新完成！';
$_['text_edit']        = '编辑商店信用';

// Entry
$_['entry_status']     = '状态';
$_['entry_sort_order'] = '排序';

// Error
$_['error_permission'] = '警告您没有权限修改商店信用！';